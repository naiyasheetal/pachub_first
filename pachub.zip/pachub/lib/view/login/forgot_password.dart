import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pachub/Utils/appcolors.dart';
import 'package:pachub/Utils/appstring.dart';
import 'package:pachub/Utils/images.dart';
import 'package:pachub/common_widget/TextField.dart';
import 'package:pachub/common_widget/button.dart';
import 'package:pachub/common_widget/textstyle.dart';
import 'package:pachub/controller/fotgot_password_controller.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key? key}) : super(key: key);

  @override
  State<ForgotPassword> createState() => _ForgotPasswordState();
}

class _ForgotPasswordState extends State<ForgotPassword> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController emailTextController = TextEditingController();
  final forgotViewController = Get.put(ForgotPasswordController());

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    setState(() {
      forgotViewController.emailTextController.text = 'darshan@gmail.in';
    });
    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Container(
          decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                splashbackimage,
              ),
              fit: BoxFit.cover,
            ),
          ),
          child:  Padding(
            padding: const EdgeInsets.only(top: 300),
            child: Container(
              // height: MediaQuery.of(context).size.height,
              width: MediaQuery.of(context).size.width,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(20),
                  topRight: Radius.circular(20),
                ),
              ),
              child: Align(
                alignment: Alignment.center,
                child: Padding(
                  padding: const EdgeInsets.only(
                      top: 50, left: 30, right: 30, bottom: 10),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        _buildColumnView(),
                        const SizedBox(height: 130),
                        _buildButtonView()
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _buildButtonView() {
    return Button(
      textColor: (forgotViewController.emailTextController.text.isEmpty)
          ? AppColors.grey_hint_color
          : AppColors.white,
      color: (forgotViewController.emailTextController.text.isEmpty)
          ? AppColors.ligt_grey_color
          : AppColors.blue_text_Color,
      text: AppString.save,
      onClick: () {
        if (_formKey.currentState!.validate()) {
          forgotViewController.apiForgotPassword(
              context: context,
              email: forgotViewController.emailTextController.text);
        }
      },
    );
  }

  _buildColumnView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Center(
          child: CommonText(
            text: AppString.pleaseForgot,
            fontSize: 24,
            color: AppColors.black_txcolor,
            fontWeight: FontWeight.w500,
          ),
        ),
        const SizedBox(height: 15),
        TextFieldView(
          controller: forgotViewController.emailTextController,
          validator: (val) {
            if (!RegExp(r'\S+@\S+\.\S+').hasMatch(val)) {
              return AppString.email_validation;
            }
            return null;
          },
          textInputAction: TextInputAction.next,
          type: TextInputType.emailAddress,
          text: "Email Address",
        ),
      ],
    );
  }
}
