import 'dart:convert';
import 'dart:developer';

import 'package:collection/collection.dart';
import 'package:dio/dio.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_swiper_view/flutter_swiper_view.dart';
import 'package:pachub/Utils/appcolors.dart';
import 'package:pachub/Utils/appstring.dart';
import 'package:pachub/app_function/MyAppFunction.dart';
import 'package:pachub/common_widget/appbar.dart';
import 'package:pachub/common_widget/textstyle.dart';
import 'package:pachub/config/preference.dart';
import 'package:pachub/models/Profile_model.dart';
import 'package:pachub/view/profile/Tabscreen/additional_details_screen.dart';
import 'package:pachub/view/profile/Tabscreen/gallery_screen.dart';
import 'package:pachub/view/profile/Tabscreen/personal_details_screen.dart';
import 'package:pachub/view/profile/Tabscreen/primary_skils_screen.dart';
import 'package:get/get.dart';
import 'package:pachub/view/profile/Tabscreen/videos_screen.dart';

import '../../Utils/constant.dart';

class TabAdminHomeDetailScreen extends StatefulWidget {
  final String userId;
  final int length;
  final Map<dynamic, Iterable<Object>> group;

  const TabAdminHomeDetailScreen(this.userId, this.length, this.group,
      {Key? key})
      : super(key: key);

  @override
  State<TabAdminHomeDetailScreen> createState() =>
      _TabAdminHomeDetailScreenState();
}

class _TabAdminHomeDetailScreenState extends State<TabAdminHomeDetailScreen> with SingleTickerProviderStateMixin {
  bool selected = false;
  TabController? tabController;
  var models = <String>{};
  List itemList = [];
  List uniquelist = [];
  int? count;
  int? value;
  bool isLoading = false;

  @override
  void initState() {
    tabController = TabController(length: widget.length, vsync: this);
    setState(() {
      manageAditionalInformationList(widget.userId);
    });
    super.initState();
    print("List Of tab length ==-===<><. ${widget.length}");
    // print("uniqueList $uniquelist");
    // print("Length of List $item");
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: Column(
        children: [
          const SizedBox(height: 11),
          _buildTabBar(),
          const SizedBox(height: 10),
          Expanded(
            child: widget.length == 1
                ? TabBarView(controller: tabController, children: [
              widget.group.keys != "Additional Information"
                  ? Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["value"][0]}");
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "AthleteSchoolYear")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"]?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] == "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem["value"]['DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500),
                                              if (totalPendingItem["columnName"] != "uploadTranscript" &&
                                                  totalPendingItem["columnName"] != "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              )
                  : Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Primary Skills") {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] ==
                                                  "positionPlayed")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] !=
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              )
            ])
                : widget.length == 2
                ? TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Primary Skills") {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] ==
                                                  "positionPlayed")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] != "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["value"][0]}");
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "AthleteSchoolYear")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem["value"]['DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                              if (totalPendingItem["columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem["columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
            ])
                : widget.length == 3
                ? TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Primary Skills") {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] == "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] != "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(context).size.width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors.black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(context).size.width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "positionPlayed")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] != "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              GalleryByIdScreen(widget.userId),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Additional Information") {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "AthleteSchoolYear")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] == "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem["value"]['DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500),
                                              if (totalPendingItem["columnName"] != "uploadTranscript" && totalPendingItem["columnName"] != "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
            ])
                : TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Primary Skills") {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] == "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] != "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "positionPlayed")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] !=
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["value"][0]}");
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem["displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight: FontWeight.w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery
                                              .of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem["columnName"] == "AthleteSchoolYear")
                                                totalPendingItem["value"][0] == totalPendingItem["options"][0]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][0]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][1]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][1]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][2]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][2]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][3]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][3]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) :
                                                totalPendingItem["value"][0] == totalPendingItem["options"][4]["id"] ?
                                                CommonText(
                                                    text: "${totalPendingItem["options"][4]["name"]}",
                                                    fontSize: 13,
                                                    color: AppColors.black_txcolor,
                                                    fontWeight: FontWeight.w500) : Container(),
                                              if (totalPendingItem["columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem["value"]['DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                              if (totalPendingItem["columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem["columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem["value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight: FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              VideosByIdScreen(widget.userId),
              GalleryByIdScreen(widget.userId),
            ]),
          ),
        ],
      ),
    );
  }

  _buildTabBar() {
    return Container(
      width: Get.width,
      height: 30,
      decoration: const BoxDecoration(
        color: AppColors.white,
      ),
      child: TabBar(
          indicatorSize: TabBarIndicatorSize.label,
          unselectedLabelColor: AppColors.black_txcolor,
          labelColor: AppColors.blue_text_Color,
          // padding: const EdgeInsets.symmetric(horizontal: 11),
          splashBorderRadius: BorderRadius.circular(15),
          isScrollable: true,
          controller: tabController,
          tabs: widget.length == 1
              ? [Tab(text: "Additional Information")]
              : widget.length == 2
              ? [
            Tab(text: "Primary Skills"),
            Tab(text: "Additional Information")
          ]
              : widget.length == 3
              ? [
            Tab(text: "Primary Skills"),
            Tab(text: "Images"),
            Tab(text: "Additional Information")
          ]
              : [
            Tab(text: "Primary Skills"),
            Tab(text: "Additional Information"),
            Tab(text: "Videos"),
            Tab(text: "Images"),
          ]

        // List.generate(widget.length , (index) {
        //   print("length ====>/. ${uniquelist[index]}");
        //
        //   return Text(uniquelist[index]["displayGroup"]);
        // }),
      ),
    );
  }

  manageAditionalInformationList(String userId) async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    setState(() {
      isLoading == true;
    });
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}/$userId",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              itemList = response.data["attribute"];
              uniquelist = response.data["attribute"]
                  .where((value) => models.add(value["displayGroup"]))
                  .toList();
              // uniquelist = response.data["attribute"].where((value) => models.add(value.toString())).toList();
              print("+++++this is item ${response.data["attribute"]}");
              print("+++++ ${uniquelist}");
            });
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }
}




class TabAdminCoachDetailScreen extends StatefulWidget {
  final String userId;
  final List itemList;
  final int length;

  const TabAdminCoachDetailScreen(this.userId, this.itemList, this.length,
      {Key? key})
      : super(key: key);

  @override
  State<TabAdminCoachDetailScreen> createState() =>
      _TabAdminCoachDetailScreenState();
}

class _TabAdminCoachDetailScreenState extends State<TabAdminCoachDetailScreen> with SingleTickerProviderStateMixin {
  bool selected = false;
  TabController? tabController;
  var models = <String>{};
  List itemList = [];
  List uniquelist = [];
  int? count;
  int? value;
  String? option = "1";
  List optionList = [];
  List pitcherList = [];
  List catcherList = [];
  List outfieldList = [];
  List infieldList = [];
  List universalList = [];

  @override
  void initState() {
    tabController = TabController(length: widget.length, vsync: this);
    manageAditionalInformationList(widget.userId);
    super.initState();
    print("List Of tab length ==-===<><. ${widget.length}");
    // print("uniqueList $uniquelist");
    // print("Length of List $item");
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: Column(
        children: [
          const SizedBox(height: 11),
          _buildTabBar(),
          const SizedBox(height: 10),
          Expanded(
            child: widget.length > 1
                ? TabBarView(controller: tabController, children: [
              VideosByIdScreen(widget.userId),
              StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          ListView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemCount: itemList.length,
                              itemBuilder: (context, index) {
                                var item = itemList[index];
                                if (item["displayGroup"] ==
                                    "Desired Positions") {
                                  optionList = item["options"];
                                  print("list ======<><> $optionList");
                                  var all = item["child_fields"];
                                  print("Data View  =========<> $all");
                                  var data = json.decode(all);
                                  log('Keys: $data');
                                  pitcherList = data["Pitcher"] ?? [];
                                  catcherList = data["Catcher"] ?? [];
                                  outfieldList = data["Outfield"] ?? [];
                                  infieldList = data["Infield"] ?? [];
                                  universalList = data["Universal"] ?? [];
                                  var newList = pitcherList +
                                      catcherList +
                                      outfieldList +
                                      infieldList +
                                      universalList;
                                  print("Data  :  $newList");
                                  return Column(
                                    children: [
                                      Container(
                                        height: 55,
                                        width:
                                        MediaQuery
                                            .of(context)
                                            .size
                                            .width,
                                        color: AppColors.checkboxColor,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 15),
                                          child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .spaceBetween,
                                            children: [
                                              const Expanded(
                                                child: CommonText(
                                                    text: 'POSITION',
                                                    fontSize: 14,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight.w500),
                                              ),
                                              Expanded(
                                                child: Container(
                                                    height: 40,
                                                    width:
                                                    MediaQuery
                                                        .of(context)
                                                        .size
                                                        .width,
                                                    padding:
                                                    const EdgeInsets.only(
                                                        left: 10.0,
                                                        right: 10.0),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      const BorderRadius
                                                          .all(
                                                          Radius.circular(
                                                              10.0)),
                                                      color: AppColors.white,
                                                      border: Border.all(
                                                        color: AppColors
                                                            .dark_blue_button_color,
                                                        width: 1,
                                                      ),
                                                    ),
                                                    child:
                                                    DropdownButtonHideUnderline(
                                                      child: DropdownButton2<
                                                          String>(
                                                        itemPadding:
                                                        const EdgeInsets
                                                            .only(
                                                            left: 14,
                                                            right: 14),
                                                        dropdownMaxHeight:
                                                        200,
                                                        dropdownWidth: 180,
                                                        dropdownPadding: null,
                                                        dropdownDecoration:
                                                        BoxDecoration(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              14),
                                                          color: Colors.white,
                                                        ),
                                                        value: option,
                                                        underline:
                                                        Container(),
                                                        isExpanded: true,
                                                        itemHeight: 35.0,
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            color: Colors
                                                                .grey[700]),
                                                        items: optionList
                                                            .map((item) {
                                                          return DropdownMenuItem(
                                                            value: item["id"]
                                                                .toString(),
                                                            child: CommonText(
                                                                text: item[
                                                                "name"]
                                                                    .toString(),
                                                                fontSize: 14,
                                                                color:
                                                                AppColors
                                                                    .black,
                                                                fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                          );
                                                        }).toList(),
                                                        hint: const CommonText(
                                                            text:
                                                            "All Positions",
                                                            fontSize: 14,
                                                            color: AppColors
                                                                .black,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500),
                                                        onChanged:
                                                            (newValue) {
                                                          setState(() =>
                                                          option =
                                                              newValue);
                                                          if (kDebugMode) {
                                                            print(
                                                                "option $option");
                                                          }
                                                          if (kDebugMode) {
                                                            print(
                                                                "optionList $option");
                                                          }
                                                        },
                                                      ),
                                                    )),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      if (option == "1")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: newList.length,
                                            itemBuilder: (context, index) {
                                              var keysData = newList[index];
                                              return Column(
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 15),
                                                    child: Row(
                                                      children: [
                                                        Expanded(
                                                          child: SizedBox(
                                                            width:
                                                            MediaQuery
                                                                .of(
                                                                context)
                                                                .size
                                                                .width,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              children: [
                                                                CommonText(
                                                                    text: keysData[
                                                                    "displayName"],
                                                                    fontSize:
                                                                    13,
                                                                    color: AppColors
                                                                        .black_txcolor,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Expanded(
                                                          child: SizedBox(
                                                            width:
                                                            MediaQuery
                                                                .of(
                                                                context)
                                                                .size
                                                                .width,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                              children: [
                                                                CommonText(
                                                                    text: keysData[
                                                                    "value"],
                                                                    fontSize:
                                                                    13,
                                                                    color: AppColors
                                                                        .black_txcolor,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  const Divider(),
                                                ],
                                              );
                                            }),
                                      if (option == "2")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: pitcherList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              pitcherList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "3")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: catcherList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              catcherList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "4")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: outfieldList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              outfieldList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "5")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: infieldList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              infieldList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "6")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: universalList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              universalList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),

                                      /*   if(option == 1)
                                                        Column(
                                                        children: List.generate(newList.length, (index) {
                                                          var keysData = newList[index];
                                                          return Column(
                                                            children: [
                                                              Padding(
                                                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child: SizedBox(
                                                                        width: MediaQuery.of(context).size.width,
                                                                        child: Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            CommonText(
                                                                                text: keysData["displayName"],
                                                                                fontSize: 13,
                                                                                color: AppColors.black_txcolor,
                                                                                fontWeight: FontWeight.w500),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      child: SizedBox(
                                                                        width: MediaQuery.of(context).size.width,
                                                                        child: Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.end,
                                                                          children: [
                                                                            CommonText(
                                                                                text: keysData["value"],
                                                                                fontSize: 13,
                                                                                color: AppColors.black_txcolor,
                                                                                fontWeight: FontWeight.w500),
                                                                          ],),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              const Divider(),
                                                            ],
                                                          );
                                                        }),
                                                      ),
                                                      if(option == 2)
                                                        Column(
                                                          children: List.generate(pitcherList.length, (index) {
                                                            return Column(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                  child: Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: pitcherList[index]["displayName"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: pitcherList[index]["value"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const Divider(),
                                                              ],
                                                            );
                                                          }),
                                                        ),
                                                      if(option == 3)
                                                        Column(
                                                          children: List.generate(catcherList.length, (index) {
                                                            return Column(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                  child: Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: catcherList[index]["displayName"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: catcherList[index]["value"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const Divider(),
                                                              ],
                                                            );
                                                          })),*/
                                    ],
                                  );
                                } else {
                                  return Container();
                                }
                              }),
                        ],
                      ),
                    );
                  }),
            ])
                : TabBarView(controller: tabController, children: [
              StatefulBuilder(
                  builder: (BuildContext context, StateSetter setState) {
                    return SingleChildScrollView(
                      child: Column(
                        children: [
                          ListView.builder(
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemCount: itemList.length,
                              itemBuilder: (context, index) {
                                var item = itemList[index];
                                if (item["displayGroup"] ==
                                    "Desired Positions") {
                                  optionList = item["options"];
                                  print("list ======<><> $optionList");
                                  var all = item["child_fields"];
                                  print("Data View  =========<> $all");
                                  var data = json.decode(all);
                                  log('Keys: $data');
                                  pitcherList = data["Pitcher"] ?? [];
                                  catcherList = data["Catcher"] ?? [];
                                  outfieldList = data["Outfield"] ?? [];
                                  infieldList = data["Infield"] ?? [];
                                  universalList = data["Universal"] ?? [];
                                  var newList = pitcherList +
                                      catcherList +
                                      outfieldList +
                                      infieldList +
                                      universalList;
                                  print("Data  :  $newList");
                                  return Column(
                                    children: [
                                      Container(
                                        height: 55,
                                        width:
                                        MediaQuery
                                            .of(context)
                                            .size
                                            .width,
                                        color: AppColors.checkboxColor,
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 15),
                                          child: Row(
                                            mainAxisAlignment:
                                            MainAxisAlignment
                                                .spaceBetween,
                                            children: [
                                              const Expanded(
                                                child: CommonText(
                                                    text: 'POSITION',
                                                    fontSize: 14,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight.w500),
                                              ),
                                              Expanded(
                                                child: Container(
                                                    height: 40,
                                                    width:
                                                    MediaQuery
                                                        .of(context)
                                                        .size
                                                        .width,
                                                    padding:
                                                    const EdgeInsets.only(
                                                        left: 10.0,
                                                        right: 10.0),
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                      const BorderRadius
                                                          .all(
                                                          Radius.circular(
                                                              10.0)),
                                                      color: AppColors.white,
                                                      border: Border.all(
                                                        color: AppColors
                                                            .dark_blue_button_color,
                                                        width: 1,
                                                      ),
                                                    ),
                                                    child:
                                                    DropdownButtonHideUnderline(
                                                      child: DropdownButton2<
                                                          String>(
                                                        itemPadding:
                                                        const EdgeInsets
                                                            .only(
                                                            left: 14,
                                                            right: 14),
                                                        dropdownMaxHeight:
                                                        200,
                                                        dropdownWidth: 180,
                                                        dropdownPadding: null,
                                                        dropdownDecoration:
                                                        BoxDecoration(
                                                          borderRadius:
                                                          BorderRadius
                                                              .circular(
                                                              14),
                                                          color: Colors.white,
                                                        ),
                                                        value: option,
                                                        underline:
                                                        Container(),
                                                        isExpanded: true,
                                                        itemHeight: 35.0,
                                                        style: TextStyle(
                                                            fontSize: 15.0,
                                                            color: Colors
                                                                .grey[700]),
                                                        items: optionList
                                                            .map((item) {
                                                          return DropdownMenuItem(
                                                            value: item["id"]
                                                                .toString(),
                                                            child: CommonText(
                                                                text: item[
                                                                "name"]
                                                                    .toString(),
                                                                fontSize: 14,
                                                                color:
                                                                AppColors
                                                                    .black,
                                                                fontWeight:
                                                                FontWeight
                                                                    .w500),
                                                          );
                                                        }).toList(),
                                                        hint: const CommonText(
                                                            text:
                                                            "All Positions",
                                                            fontSize: 14,
                                                            color: AppColors
                                                                .black,
                                                            fontWeight:
                                                            FontWeight
                                                                .w500),
                                                        onChanged:
                                                            (newValue) {
                                                          setState(() =>
                                                          option =
                                                              newValue);
                                                          if (kDebugMode) {
                                                            print(
                                                                "option $option");
                                                          }
                                                          if (kDebugMode) {
                                                            print(
                                                                "optionList $option");
                                                          }
                                                        },
                                                      ),
                                                    )),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 10),
                                      if (option == "1")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: newList.length,
                                            itemBuilder: (context, index) {
                                              var keysData = newList[index];
                                              return Column(
                                                children: [
                                                  Padding(
                                                    padding: const EdgeInsets
                                                        .symmetric(
                                                        horizontal: 15),
                                                    child: Row(
                                                      children: [
                                                        Expanded(
                                                          child: SizedBox(
                                                            width:
                                                            MediaQuery
                                                                .of(
                                                                context)
                                                                .size
                                                                .width,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .start,
                                                              children: [
                                                                CommonText(
                                                                    text: keysData[
                                                                    "displayName"],
                                                                    fontSize:
                                                                    13,
                                                                    color: AppColors
                                                                        .black_txcolor,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                        Expanded(
                                                          child: SizedBox(
                                                            width:
                                                            MediaQuery
                                                                .of(
                                                                context)
                                                                .size
                                                                .width,
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment
                                                                  .end,
                                                              children: [
                                                                CommonText(
                                                                    text: keysData[
                                                                    "value"],
                                                                    fontSize:
                                                                    13,
                                                                    color: AppColors
                                                                        .black_txcolor,
                                                                    fontWeight:
                                                                    FontWeight
                                                                        .w500),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                  const Divider(),
                                                ],
                                              );
                                            }),
                                      if (option == "2")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: pitcherList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              pitcherList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "3")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: catcherList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              catcherList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "4")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: outfieldList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              outfieldList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "5")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: infieldList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              infieldList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),
                                      if (option == "6")
                                        ListView.builder(
                                            physics:
                                            const NeverScrollableScrollPhysics(),
                                            shrinkWrap: true,
                                            itemCount: universalList.length,
                                            itemBuilder: (context, index) {
                                              var keysData =
                                              universalList[index];
                                              if (keysData != null) {
                                                return Column(
                                                  children: [
                                                    Padding(
                                                      padding:
                                                      const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 15),
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .start,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "displayName"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                          Expanded(
                                                            child: SizedBox(
                                                              width: MediaQuery
                                                                  .of(
                                                                  context)
                                                                  .size
                                                                  .width,
                                                              child: Column(
                                                                crossAxisAlignment:
                                                                CrossAxisAlignment
                                                                    .end,
                                                                children: [
                                                                  CommonText(
                                                                      text: keysData[
                                                                      "value"],
                                                                      fontSize:
                                                                      13,
                                                                      color: AppColors
                                                                          .black_txcolor,
                                                                      fontWeight:
                                                                      FontWeight
                                                                          .w500),
                                                                ],
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                    const Divider(),
                                                  ],
                                                );
                                              } else {
                                                return const Center(
                                                    child: Text(
                                                        "No Data Found"));
                                              }
                                            }),

                                      /*   if(option == 1)
                                                        Column(
                                                        children: List.generate(newList.length, (index) {
                                                          var keysData = newList[index];
                                                          return Column(
                                                            children: [
                                                              Padding(
                                                                padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                child: Row(
                                                                  children: [
                                                                    Expanded(
                                                                      child: SizedBox(
                                                                        width: MediaQuery.of(context).size.width,
                                                                        child: Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                                          children: [
                                                                            CommonText(
                                                                                text: keysData["displayName"],
                                                                                fontSize: 13,
                                                                                color: AppColors.black_txcolor,
                                                                                fontWeight: FontWeight.w500),
                                                                          ],
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    Expanded(
                                                                      child: SizedBox(
                                                                        width: MediaQuery.of(context).size.width,
                                                                        child: Column(
                                                                          crossAxisAlignment: CrossAxisAlignment.end,
                                                                          children: [
                                                                            CommonText(
                                                                                text: keysData["value"],
                                                                                fontSize: 13,
                                                                                color: AppColors.black_txcolor,
                                                                                fontWeight: FontWeight.w500),
                                                                          ],),
                                                                      ),
                                                                    ),
                                                                  ],
                                                                ),
                                                              ),
                                                              const Divider(),
                                                            ],
                                                          );
                                                        }),
                                                      ),
                                                      if(option == 2)
                                                        Column(
                                                          children: List.generate(pitcherList.length, (index) {
                                                            return Column(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                  child: Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: pitcherList[index]["displayName"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: pitcherList[index]["value"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const Divider(),
                                                              ],
                                                            );
                                                          }),
                                                        ),
                                                      if(option == 3)
                                                        Column(
                                                          children: List.generate(catcherList.length, (index) {
                                                            return Column(
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets.symmetric(horizontal: 15),
                                                                  child: Row(
                                                                    children: [
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: catcherList[index]["displayName"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],
                                                                          ),
                                                                        ),
                                                                      ),
                                                                      Expanded(
                                                                        child: SizedBox(
                                                                          width: MediaQuery.of(context).size.width,
                                                                          child: Column(
                                                                            crossAxisAlignment: CrossAxisAlignment.end,
                                                                            children: [
                                                                              CommonText(
                                                                                  text: catcherList[index]["value"],
                                                                                  fontSize: 13,
                                                                                  color: AppColors.black_txcolor,
                                                                                  fontWeight: FontWeight.w500),
                                                                            ],),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                const Divider(),
                                                              ],
                                                            );
                                                          })),*/
                                    ],
                                  );
                                } else {
                                  return Container();
                                }
                              }),
                        ],
                      ),
                    );
                  }),
            ]),
          )
        ],
      ),
    );
  }

  _buildTabBar() {
    return Container(
      width: Get.width,
      height: 30,
      decoration: const BoxDecoration(
        color: AppColors.white,
      ),
      child: TabBar(
        indicatorSize: TabBarIndicatorSize.label,
        unselectedLabelColor: AppColors.black_txcolor,
        labelColor: AppColors.blue_text_Color,
        // padding: const EdgeInsets.symmetric(horizontal: 11),
        splashBorderRadius: BorderRadius.circular(15),
        isScrollable: true,
        controller: tabController,
        tabs: List.generate(widget.itemList.length, (index) {
          print("length ====>/. ${widget.itemList[index]}");
          return Text(widget.itemList[index]["displayGroup"]);
        }),
      ),
    );
  }

  manageAditionalInformationList(String userId) async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}/$userId",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              itemList = response.data["attribute"];
              uniquelist = response.data["attribute"]
                  .where((value) => models.add(value["displayGroup"]))
                  .toList();
              // uniquelist = response.data["attribute"].where((value) => models.add(value.toString())).toList();
              print("+++++this is item ${response.data["attribute"]}");
            });
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }
}



class TabAdminAdvisorDetailScreen extends StatefulWidget {
  final String userId;
  final int length;

  const TabAdminAdvisorDetailScreen(this.userId, this.length, {Key? key})
      : super(key: key);

  @override
  State<TabAdminAdvisorDetailScreen> createState() =>
      _TabAdminAdvisorDetailScreenState();
}

class _TabAdminAdvisorDetailScreenState extends State<TabAdminAdvisorDetailScreen> with SingleTickerProviderStateMixin {
  bool selected = false;
  TabController? tabController;
  var models = <String>{};
  List itemList = [];
  List uniquelist = [];
  int? count;
  int? value;
  bool isLoading = false;

  @override
  void initState() {
    tabController = TabController(length: widget.length, vsync: this);
    setState(() {
      manageAditionalInformationList(widget.userId);
    });
    super.initState();
    print("List Of tab length ==-===<><. ${widget.length}");
    // print("uniqueList $uniquelist");
    // print("Length of List $item");
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: Column(
        children: [
          const SizedBox(height: 11),
          _buildTabBar(),
          const SizedBox(height: 10),
          Expanded(
              child: TabBarView(controller: tabController, children: [
                VideosByIdScreen(widget.userId),
              ])),
        ],
      ),
    );
  }

  _buildTabBar() {
    return Container(
      width: Get.width,
      height: 30,
      decoration: const BoxDecoration(
        color: AppColors.white,
      ),
      child: TabBar(
          indicatorSize: TabBarIndicatorSize.label,
          unselectedLabelColor: AppColors.black_txcolor,
          labelColor: AppColors.blue_text_Color,
          // padding: const EdgeInsets.symmetric(horizontal: 11),
          splashBorderRadius: BorderRadius.circular(15),
          isScrollable: true,
          controller: tabController,
          tabs: [Tab(text: "Videos")]

        // List.generate(widget.length , (index) {
        //   print("length ====>/. ${uniquelist[index]}");
        //
        //   return Text(uniquelist[index]["displayGroup"]);
        // }),
      ),
    );
  }

  manageAditionalInformationList(String userId) async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    setState(() {
      isLoading == true;
    });
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}/$userId",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              itemList = response.data["attribute"];
              uniquelist = response.data["attribute"]
                  .where((value) => models.add(value["displayGroup"]))
                  .toList();
              // uniquelist = response.data["attribute"].where((value) => models.add(value.toString())).toList();
              print("+++++this is item ${response.data["attribute"]}");
              print("+++++ ${itemList.toString()}");
            });
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }
}

/*class TabTestingAdminHomeDetailScreen extends StatefulWidget {
  final String userId;
  final int length;
  final Map<dynamic, Iterable<Object>> group;
  final List uniquelist;
  const TabTestingAdminHomeDetailScreen(this.userId, this.length,this.group, this.uniquelist, {Key? key}) : super(key: key);

  @override
  State<TabTestingAdminHomeDetailScreen> createState() =>
      _TabTestingAdminHomeDetailScreenState();
}

class _TabTestingAdminHomeDetailScreenState extends State<TabTestingAdminHomeDetailScreen>
    with SingleTickerProviderStateMixin {
  bool selected = false;
  TabController? tabController;
  var models = <String>{};
  List itemList = [];
  List uniquelist = [];
  int? count;
  int? value;
  bool isLoading = false;

  @override
  void initState() {
    tabController = TabController(length: widget.length, vsync: this);
    setState(() {
      manageAditionalInformationList(widget.userId);
    });
    super.initState();
    print("List Of tab length ==-===<><. ${widget.length}");
    // print("uniqueList $uniquelist");
    // print("Length of List $item");
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 300,
      child: Column(
        children: [
          const SizedBox(height: 11),
          _buildTabBar(),
          const SizedBox(height: 10),
          Expanded(
            child: widget.length == 1
                ? TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding:
                      const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["options"]}");
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "AthleteSchoolYear")
                                                if (totalPendingItem[
                                                "value"][0] ==
                                                    totalPendingItem[
                                                    "options"]
                                                    [3]["id"])
                                                  CommonText(
                                                      text:
                                                      "${totalPendingItem["options"][3]["name"]}",
                                                      fontSize: 13,
                                                      color: AppColors
                                                          .black_txcolor,
                                                      fontWeight:
                                                      FontWeight
                                                          .w500),
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [
                                                    'DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem[
                                                  "columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text:
                                                    totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
            ])
                : widget.length == 2
                ? TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding:
                      const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Primary Skills") {
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [0]
                                                        .toString(),
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "positionPlayed")
                                                CommonText(
                                                    text:
                                                    totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding:
                      const EdgeInsets.symmetric(horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["options"]}");
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem["columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem["columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width:
                                          MediaQuery.of(context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "AthleteSchoolYear")
                                                if (totalPendingItem[
                                                "value"][0] ==
                                                    totalPendingItem[
                                                    "options"]
                                                    [3]["id"])
                                                  CommonText(
                                                      text:
                                                      "${totalPendingItem["options"][3]["name"]}",
                                                      fontSize: 13,
                                                      color: AppColors
                                                          .black_txcolor,
                                                      fontWeight:
                                                      FontWeight
                                                          .w500),
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [
                                                    'DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem[
                                                  "columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text:
                                                    totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
            ])
                : widget.length == 3
                ? TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Primary Skills") {
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem[
                                "columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem[
                                "columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [0]
                                                        .toString(),
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              GalleryByIdScreen(widget.userId),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] == "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["options"]}");
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem[
                                "columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem[
                                "columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "AthleteSchoolYear")
                                                if (totalPendingItem[
                                                "value"]
                                                [0] ==
                                                    totalPendingItem[
                                                    "options"]
                                                    [3]["id"])
                                                  CommonText(
                                                      text:
                                                      "${totalPendingItem["options"][3]["name"]}",
                                                      fontSize:
                                                      13,
                                                      color: AppColors
                                                          .black_txcolor,
                                                      fontWeight:
                                                      FontWeight
                                                          .w500),
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [
                                                    'DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem[
                                                  "columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
            ])
                : TabBarView(controller: tabController, children: [
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Primary Skills") {
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem[
                                "columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem[
                                "columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [0]
                                                        .toString(),
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "positionPlayed")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              Column(
                children: [
                  Container(
                    height: 40,
                    width: MediaQuery.of(context).size.width,
                    color: AppColors.drawer_bottom_text_color,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 15),
                      child: Row(
                        mainAxisAlignment:
                        MainAxisAlignment.spaceBetween,
                        children: const [
                          CommonText(
                              text: "ATTRIBUTE NAME",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                          CommonText(
                              text: "DESCRIPTION",
                              fontSize: 14,
                              color: AppColors.white,
                              fontWeight: FontWeight.w600),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 5),
                  Expanded(
                    child: ListView.builder(
                        shrinkWrap: true,
                        itemCount: itemList.length,
                        itemBuilder: (context, index) {
                          var totalPendingItem = itemList[index];
                          if (totalPendingItem["displayGroup"] ==
                              "Additional Information") {
                            if (totalPendingItem["columnName"] ==
                                "AthleteSchoolYear")
                              print(
                                  "optionsList =====>  ${totalPendingItem["options"]}");
                            return Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                if (totalPendingItem[
                                "columnName"] ==
                                    "uploadTranscript")
                                  Container(),
                                if (totalPendingItem[
                                "columnName"] !=
                                    "uploadTranscript")
                                  const SizedBox(height: 5),
                                Padding(
                                  padding:
                                  const EdgeInsets.symmetric(
                                      horizontal: 15),
                                  child: Row(
                                    children: [
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .start,
                                            children: [
                                              CommonText(
                                                  text: totalPendingItem[
                                                  "displayName"],
                                                  fontSize: 13,
                                                  color: AppColors
                                                      .black_txcolor,
                                                  fontWeight:
                                                  FontWeight
                                                      .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                      Expanded(
                                        child: SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width,
                                          child: Column(
                                            crossAxisAlignment:
                                            CrossAxisAlignment
                                                .end,
                                            children: [
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "AthleteSchoolYear")
                                                if (totalPendingItem[
                                                "value"]
                                                [0] ==
                                                    totalPendingItem[
                                                    "options"]
                                                    [3]["id"])
                                                  CommonText(
                                                      text:
                                                      "${totalPendingItem["options"][3]["name"]}",
                                                      fontSize:
                                                      13,
                                                      color: AppColors
                                                          .black_txcolor,
                                                      fontWeight:
                                                      FontWeight
                                                          .w500),
                                              if (totalPendingItem[
                                              "columnName"] ==
                                                  "uploadTranscript")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"]
                                                    [
                                                    'DisplayName'],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                              if (totalPendingItem[
                                              "columnName"] !=
                                                  "uploadTranscript" &&
                                                  totalPendingItem[
                                                  "columnName"] !=
                                                      "AthleteSchoolYear")
                                                CommonText(
                                                    text: totalPendingItem[
                                                    "value"],
                                                    fontSize: 13,
                                                    color: AppColors
                                                        .black_txcolor,
                                                    fontWeight:
                                                    FontWeight
                                                        .w500),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                // ListView.builder(
                                //   shrinkWrap: true,
                                //     itemCount : totalPendingItem["options"],
                                //     itemBuilder: (context, index) {
                                //   return  totalPendingItem["value"][0] == totalPendingItem["options"][index]["id"] ?  CommonText(
                                //         text: "${totalPendingItem["options"][index]["name"]}",
                                //         fontSize: 13,
                                //         color: AppColors.black_txcolor,
                                //         fontWeight: FontWeight.w500) : Container();
                                // }
                                // ),
                                const Divider(),
                              ],
                            );
                          } else {
                            return Container();
                          }
                        }),
                  ),
                ],
              ),
              VideosByIdScreen(widget.userId),
              GalleryByIdScreen(widget.userId),
            ]),
          ),
        ],
      ),
    );
  }

  _buildTabBar() {
    return Container(
      width: Get.width,
      height: 30,
      decoration: const BoxDecoration(
        color: AppColors.white,
      ),
      child: TabBar(
          indicatorSize: TabBarIndicatorSize.label,
          unselectedLabelColor: AppColors.black_txcolor,
          labelColor: AppColors.blue_text_Color,
          // padding: const EdgeInsets.symmetric(horizontal: 11),
          splashBorderRadius: BorderRadius.circular(15),
          isScrollable: true,
          controller: tabController,
          tabs: List.generate(widget.uniquelist.length, (index) {
            return Text(widget.uniquelist[index]);
          }),
          // widget.length == 1
          //     ?  [Tab(text: "Primary Skills")]
          //     : widget.length == 2
          //     ? [
          //   Tab(text: "Primary Skills"),
          //   Tab(text: "Additional Information")
          // ]
          //     : widget.length == 3
          //     ? [
          //   Tab(text: "Primary Skills"),
          //   Tab(text: "Images"),
          //   Tab(text: "Additional Information")
          // ]
          //     : [
          //   Tab(text: "Primary Skills"),
          //   Tab(text: "Additional Information"),
          //   Tab(text: "Videos"),
          //   Tab(text: "Images"),
          // ]

        // List.generate(widget.length , (index) {
        //   print("length ====>/. ${uniquelist[index]}");
        //
        //   return Text(uniquelist[index]["displayGroup"]);
        // }),
      ),
    );
  }

  manageAditionalInformationList(String userId) async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    setState(() {
      isLoading == true;
    });
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}/$userId",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              itemList = response.data["attribute"];
              uniquelist = response.data["attribute"]
                  .where((value) => models.add(value["displayGroup"]))
                  .toList();
              // uniquelist = response.data["attribute"].where((value) => models.add(value.toString())).toList();
              print("+++++this is item ${response.data["attribute"]}");
              print("+++++ ${uniquelist}");
            });
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }
}*/
