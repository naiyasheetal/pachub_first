import 'dart:developer';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:pachub/Utils/appcolors.dart';
import 'package:pachub/Utils/appstring.dart';
import 'package:pachub/Utils/constant.dart';
import 'package:pachub/common_widget/textstyle.dart';
import 'package:pachub/config/preference.dart';

import '../../../app_function/MyAppFunction.dart';
import '../../../common_widget/customloader.dart';
import '../../../common_widget/nodatafound_page.dart';


class PrimarySkilsScreen extends StatefulWidget {
  const PrimarySkilsScreen({Key? key}) : super(key: key);

  @override
  State<PrimarySkilsScreen> createState() => _PrimarySkilsScreenState();
}

class _PrimarySkilsScreenState extends State<PrimarySkilsScreen> {
  List athleteItemList = [];
  bool _isFirstLoadRunning = false;

  @override
  void initState() {
    manageAditionalInformationList();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _isFirstLoadRunning
          ? athleteItemList.isEmpty
          ? Align(
        alignment: Alignment.center,
        child: CustomLoader(),
      ) : const Align(
        alignment: Alignment.center,
        child: NoDataFound(),
      ) :
      ListView.builder(
        padding: const EdgeInsets.only(top: 10),
        shrinkWrap: true,
        itemCount: athleteItemList.length,
        itemBuilder: (context, index) {
          if (athleteItemList[index]["displayGroup"] == "Primary Skills") {
            return  Padding(
              padding: const EdgeInsets.symmetric(
                  horizontal: 15, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if(athleteItemList[index]["columnName"] == "positionPlayed")
                      _buildColumn(athleteItemList[index]["columnName"], "${athleteItemList[index]["options"][2]["name"] ?? ""}"),
                  if(athleteItemList[index]["columnName"] != "positionPlayed")
                    _buildColumn(athleteItemList[index]["columnName"], athleteItemList[index]["value"] ?? "")
                ],
              ),
            );
          }  else {
            return  Container();
          }
        },
      ),
    );
  }

  _buildColumn(title, subTxt) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CommonText(text: title, fontSize: 13, color: AppColors.black_txcolor, fontWeight: FontWeight.w500),
        SizedBox(height: 5),
        Container(
          height: 40,
          width: double.infinity,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            color: AppColors.contacts_text_color,
            border: Border.all(
                color: AppColors.grey_hint_color, width: 1),
          ),
          child:  Padding(
            padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            child: CommonText(
                text: subTxt,
                fontSize: 15,
                color: AppColors.blacksubtext_color,
                fontWeight: FontWeight.w400),
          ),
        )
      ],
    );
  }
  manageAditionalInformationList() async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get(AppConstant.mamage_profile,
              options: Options(followRedirects: false, headers: {
                "Authorization":
                "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              athleteItemList = response.data["attribute"];
              print("+++++this is item ${response.data["attribute"]}");
            });
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }

}
