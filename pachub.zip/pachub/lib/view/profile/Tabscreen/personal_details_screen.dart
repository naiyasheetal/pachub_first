import 'dart:developer';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:pachub/Utils/appcolors.dart';
import 'package:pachub/Utils/appstring.dart';
import 'package:pachub/Utils/constant.dart';
import 'package:pachub/Utils/images.dart';
import 'package:pachub/app_function/MyAppFunction.dart';
import 'package:pachub/common_widget/customloader.dart';
import 'package:pachub/common_widget/textstyle.dart';
import 'package:get/get.dart';
import 'package:pachub/config/preference.dart';
import 'package:pachub/view/login/login_view.dart';
import 'package:url_launcher/url_launcher.dart';


///////Todo PersonalDetails view /////////


class PersonalDetailsScreen extends StatefulWidget {
  const PersonalDetailsScreen({Key? key}) : super(key: key);

  @override
  State<PersonalDetailsScreen> createState() => _PersonalDetailsScreenState();
}

class _PersonalDetailsScreenState extends State<PersonalDetailsScreen> {
  var athleteuserdetails = {};
  bool _isFirstLoadRunning = false;


  @override
  void initState() {
    setState(() {});
    super.initState();
    Manage_Profile(); //Manage_Profile(userid);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: athleteuserdetails.isEmpty
            ? athleteuserdetails.isEmpty
                ? Center(child: CustomLoader())
                : Center(
                    child: Text("No Data Found"),
                  )
            : Padding(
                padding: const EdgeInsets.only(
                    left: 21, right: 21, top: 20, bottom: 0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(4),
                        height: 150,
                        width: 150,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10000.0),
                          child: Image.network(
                            "${athleteuserdetails["picturePathS3"]}",
                            fit: BoxFit.cover,
                            errorBuilder: (BuildContext context,
                                Object exception, StackTrace? stackTrace) {
                              print("Exception >> ${exception.toString()}");
                              return Image.asset(avatarImage);
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      CommonText(
                          text: "${athleteuserdetails["displayName"]}",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      const SizedBox(height: 5),
                      athleteuserdetails["DOB"] != null
                          ? _builRowView(
                              cakeIcon, "${athleteuserdetails["DOB"]??""}")
                          : Container(),
                      const SizedBox(height: 8),
                      athleteuserdetails["userEmail"] != null
                          ? _builRowView(
                              emailIcon, "${athleteuserdetails["userEmail"]}")
                          : Container(),
                      const SizedBox(height: 8),
                      athleteuserdetails["contact"] != null
                          ? _builRowView(
                              call_icon, "${athleteuserdetails["contact"]}")
                          : Container(),
                      const SizedBox(height: 8),
                      _buildLocationView(),
                      const SizedBox(height: 15),
                      const CommonText(
                          text: "Organization Detail",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      const SizedBox(height: 8),
                      athleteuserdetails["organizationName"] != null
                          ? CommonText(
                              text: athleteuserdetails["organizationName"],
                              fontSize: 14,
                              color: AppColors.black,
                              fontWeight: FontWeight.w500)
                          : Container(),
                      const SizedBox(height: 10),
                      athleteuserdetails["organizationAddress"] != null
                          ? CommonText(
                              text:
                                  "${athleteuserdetails["organizationAddress"]},${athleteuserdetails["organizationCity"]}, ${athleteuserdetails["organizationState"]},${athleteuserdetails["organizationZipcode"]}",
                              fontSize: 14,
                              color: AppColors.black,
                              fontWeight: FontWeight.w400)
                          : Container(),
                      const SizedBox(height: 10),
                      athleteuserdetails["coachRole"] != null
                          ? Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const CommonText(
                                        text: "My Division",
                                        fontSize: 16,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w700),
                                    const SizedBox(height: 5),
                                    CommonText(
                                        text: "D1",
                                        fontSize: 14,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w400),
                                  ],
                                ),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const CommonText(
                                        text: "Coach Role",
                                        fontSize: 16,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w700),
                                    const SizedBox(height: 5),
                                    CommonText(
                                        text:
                                            "${athleteuserdetails["coachRole"]}",
                                        fontSize: 14,
                                        color: AppColors.black,
                                        fontWeight: FontWeight.w400),
                                  ],
                                )
                              ],
                            )
                          : Container(),
                      const SizedBox(height: 10),
                      const CommonText(
                          text: "About",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      const SizedBox(height: 10),
                      athleteuserdetails["bio"] != null
                          ? CommonText(
                              text: "${athleteuserdetails["bio"]}",
                              fontSize: 14,
                              color: AppColors.black,
                              fontWeight: FontWeight.w400)
                          : Container(),
                      const SizedBox(height: 16),
                      _buildContainer("${athleteuserdetails["profileName"]}"),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              )
    );
  }

  _builRowView(image, text) {
    return Row(children: [
      SvgPicture.asset(image),
      const SizedBox(width: 5),
      CommonText(
          text: text,
          fontSize: 14,
          color: AppColors.black,
          fontWeight: FontWeight.w400),
    ]);
  }

  _buildLocationView() {
    return Row(children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: SvgPicture.asset(locationIcon),
      ),
      const SizedBox(width: 5),
      Expanded(
        child: CommonText(
            text:
                "${athleteuserdetails["streetAddress"] ?? " No Information"}" +
                    ", " +
                    "${athleteuserdetails["landMark"] ?? " No Information"}" +
                    ", " +
                    "${athleteuserdetails["city"] ?? " No Information"}" +
                    ", " +
                    "${athleteuserdetails["state"] ?? " No Information"}" +
                    " - " +
                    "${athleteuserdetails["zipcode"] ?? " No Information"}",
            fontSize: 14,
            color: AppColors.black,
            fontWeight: FontWeight.w400),
      ),
    ]);
  }

  _buildWorldView() {
    return Row(children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: SvgPicture.asset(world_icon),
      ),
      const SizedBox(width: 5),
      const CommonText(
          text: AppString.privateProfileText,
          fontSize: 12,
          color: AppColors.blacksubtext_color,
          fontWeight: FontWeight.w400),
    ]);
  }

  _buildContainer(String profileName) {
    return Card(
      elevation: 0,
      color: AppColors.profileColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildWorldView(),
            const SizedBox(height: 4),
             Padding(
              padding: EdgeInsets.only(left: 23),
              child: InkWell(
                onTap: () async {
                  await profile_lounch(profileName);
                  _launchUrl(profileName);
                  print("profile Name  ======> $profileName");
                },
                child: Expanded(
                  child: CommonText(
                      text: "http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileName",
                      fontSize: 16,
                      color: AppColors.blue_button_Color,
                      fontWeight: FontWeight.w400),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _launchUrl(String profileLink) async {
    if (!await launchUrl(Uri.parse("http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileLink"))) {
      throw 'Could not launch ${"http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileLink"}';
    }
  }


  Manage_Profile() async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                    "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              athleteuserdetails = response.data["userdetails"];
              print("---this is profile data== $athleteuserdetails");
              print(
                  "profile picture path--- ${athleteuserdetails["picturePathS3"]}");
            });
          } else if (response.statusCode == 401) {
            return Get.offAll(Loginscreennew());
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }

  /////TODO publicprofile Loanch Api /////////
  profile_lounch(String profilelink) async {
    log('this is call profile_lounch api call', name: "Profile Link");
    try {
      Dio dio = Dio();
      var params = {
        "url":"http://packhubweb.s3-website-us-west-2.amazonaws.com/$profilelink"
      };
      print("response url  ====> ${params}");
      var response = await dio.post(AppConstant.public_profile,
          data: params,
          options: Options(followRedirects: false, headers: {
            "Authorization":
            "Bearer ${PreferenceUtils.getString("accesstoken")}"
          }));
      if (response.statusCode == 200) {
        print("+++++this is admin clg recruiter${response.data}");
        // if (await canLaunchUrl(Uri.parse())){
        //   await launchUrl(Uri.parse("http://packhubweb.s3-website-us-west-2.amazonaws.com/zelizelensky"));
        // } else {
        //   // can't launch url
        // }
      }
    } catch (e) {
      print(e);
      setState(() => _isFirstLoadRunning = false);
    }
  }
}



///////Todo AthletePersonalDetails view /////////

class AthletePersonalDetailsScreen extends StatefulWidget {
  const AthletePersonalDetailsScreen({Key? key}) : super(key: key);

  @override
  State<AthletePersonalDetailsScreen> createState() =>
      _AthletePersonalDetailsScreenState();
}

class _AthletePersonalDetailsScreenState
    extends State<AthletePersonalDetailsScreen> {
  var athleteuserdetails = {};
  var persnoledetails = {};
  List collageName = [];
  bool _isFirstLoadRunning = false;


  @override
  void initState() {
    setState(() {});
    super.initState();
    Manage_Profile(); //Manage_Profile(userid);
  }

  @override
  Widget build(BuildContext context) {
    collageName.add(athleteuserdetails["collegeName"]);
    return Scaffold(
        body: athleteuserdetails.isEmpty
            ? athleteuserdetails.isEmpty
                ? Center(child: CustomLoader())
                : Center(
                    child: Text("No Data Found"),
                  )
            : Padding(
                padding: const EdgeInsets.only(
                    left: 21, right: 21, top: 20, bottom: 0),
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: EdgeInsets.all(4),
                        height: 150,
                        width: 150,
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(10000.0),
                          child: Image.network(
                            "${athleteuserdetails["picturePathS3"]}",
                            fit: BoxFit.cover,
                            errorBuilder: (BuildContext context,
                                Object exception, StackTrace? stackTrace) {
                              print("Exception >> ${exception.toString()}");
                              return Image.asset(avatarImage);
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 24),
                      CommonText(
                          text: "${athleteuserdetails["displayName"]}",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      const SizedBox(height: 5),
                      athleteuserdetails["DOB"] != null
                          ? _builRowView(
                              cakeIcon, "${athleteuserdetails["DOB"]}")
                          : Container(),
                      const SizedBox(height: 8),
                      athleteuserdetails["userEmail"] != null
                          ? _builRowView(
                              emailIcon, "${athleteuserdetails["userEmail"]}")
                          : Container(),
                      const SizedBox(height: 8),
                      athleteuserdetails["contact"] != null
                          ? _builRowView(
                              call_icon, "${athleteuserdetails["contact"]}")
                          : Container(),
                      const SizedBox(height: 8),
                      _buildLocationView(),
                      const SizedBox(height: 15),
                      /*const CommonText(
                          text: "Colleges I Am Interested In",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),*/
                      const SizedBox(height: 15),
                      /*  CommonText(
                          text:  "${athleteuserdetails["collegeName"][0]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),
                      const SizedBox(height: 5),
                      CommonText(
                          text:  "${athleteuserdetails["collegeName"][1]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),
                      const SizedBox(height: 5),
                      CommonText(
                          text: "${athleteuserdetails["collegeName"][2]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),
                      const SizedBox(height: 5),
                      CommonText(
                          text: "${athleteuserdetails["collegeName"][3]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),
                      const SizedBox(height: 5),
                      CommonText(
                          text: "${athleteuserdetails["collegeName"][4]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),*/
                      const SizedBox(height: 15),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CommonText(
                                    text: "Current School",
                                    fontSize: 16,
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w700),
                                const SizedBox(height: 5),
                                CommonText(
                                    text:
                                    "${athleteuserdetails["currentSchool"]??"No Information"}",
                                    fontSize: 14,
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w400),
                              ],
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CommonText(
                                    text: "Graduating Senior Age",
                                    fontSize: 16,
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w700),
                                const SizedBox(height: 5),
                                CommonText(
                                    text: "${athleteuserdetails["ageAtDraft"]??"No Information"}",
                                    fontSize: 14,
                                    color: AppColors.black,
                                    fontWeight: FontWeight.w400),
                              ],
                            ),
                          ]),
                      const SizedBox(height: 15),
                      Row(children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const CommonText(
                                  text: "Height",
                                  fontSize: 16,
                                  color: AppColors.black,
                                  fontWeight: FontWeight.w700),
                              const SizedBox(height: 5),
                              CommonText(
                                  text:
                                  "${athleteuserdetails["height"]??"No Information"}(Feet-Inches)",
                                  fontSize: 14,
                                  color: AppColors.black,
                                  fontWeight: FontWeight.w400),
                            ],
                          ),
                        ),
                        const SizedBox(width: 45),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CommonText(
                                text: "Weight",
                                fontSize: 16,
                                color: AppColors.black,
                                fontWeight: FontWeight.w700),
                            const SizedBox(height: 5),
                            CommonText(
                                text: "${athleteuserdetails["weight"]??"No Information"}(Lbs.)",
                                fontSize: 14,
                                color: AppColors.black,
                                fontWeight: FontWeight.w400),
                          ],
                        ),
                      ]),
                      const SizedBox(height: 15),
                      const CommonText(
                          text: "Committed To",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      CommonText(
                          text: "${athleteuserdetails["committedTo"]??"No Information"}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400),
                      const SizedBox(height: 15),
                      const CommonText(
                          text: "About",
                          fontSize: 16,
                          color: AppColors.black,
                          fontWeight: FontWeight.w700),
                      const SizedBox(height: 10),
                      athleteuserdetails["bio"] != null
                          ? CommonText(
                          text: "${athleteuserdetails["bio"]}",
                          fontSize: 14,
                          color: AppColors.black,
                          fontWeight: FontWeight.w400)
                          : Container(
                         child: CommonText(
                              text: "No Information",
                              fontSize: 14,
                              color: AppColors.black,
                              fontWeight: FontWeight.w400)
                      ),
                      const SizedBox(height: 15),
                      const SizedBox(height: 16),
                      _buildContainer("${athleteuserdetails["profileName"]}"),
                      const SizedBox(height: 10),
                    ],
                  ),
                ),
              ));
  }

  _builRowView(image, text) {
    return Row(children: [
      SvgPicture.asset(image),
      const SizedBox(width: 5),
      CommonText(
          text: text,
          fontSize: 14,
          color: AppColors.black,
          fontWeight: FontWeight.w400),
    ]);
  }

  _buildLocationView() {
    return Row(children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: SvgPicture.asset(locationIcon),
      ),
      const SizedBox(width: 5),
      Expanded(
        child: CommonText(
            text:
                "${athleteuserdetails["streetAddress"] ?? ""}" +
                    ", " +
                    "${athleteuserdetails["landMark"] ?? ""}" +
                    ", " +
                    "${athleteuserdetails["city"] ?? ""}" +
                    ", " +
                    "${athleteuserdetails["state"] ?? ""}" +
                    " - " +
                    "${athleteuserdetails["zipcode"] ?? ""}",
            fontSize: 14,
            color: AppColors.black,
            fontWeight: FontWeight.w400),
      ),
    ]);
  }

  _buildWorldView() {
    return Row(children: [
      Padding(
        padding: const EdgeInsets.only(bottom: 15),
        child: SvgPicture.asset(world_icon),
      ),
      const SizedBox(width: 5),
      const CommonText(
          text: AppString.privateProfileText,
          fontSize: 12,
          color: AppColors.blacksubtext_color,
          fontWeight: FontWeight.w400),
    ]);
  }

  _buildContainer(String profileName) {
    return Card(
      elevation: 0,
      color: AppColors.profileColor,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildWorldView(),
            const SizedBox(height: 4),
             Padding(
              padding: EdgeInsets.only(left: 23),
              child: InkWell(
                onTap: () async {
                  await profile_lounch(profileName);
                  _launchUrl(profileName);
                  print("profile Name  ======> $profileName");
                },
                child: CommonText(
                    text: "http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileName",
                    fontSize: 16,
                    color: AppColors.blue_button_Color,
                    fontWeight: FontWeight.w400),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _launchUrl(String profileLink) async {
    if (!await launchUrl(Uri.parse("http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileLink"))) {
      throw 'Could not launch ${"http://packhubweb.s3-website-us-west-2.amazonaws.com/profile/$profileLink"}';
    }
  }

  Manage_Profile() async {
    log('this is Manage_Profile  api call', name: "Manage_Profile");
    MyApplication.getInstance()!
        .checkConnectivity(context)
        .then((internet) async {
      if (internet != null && internet) {
        try {
          Dio dio = Dio();
          var response = await dio.get("${AppConstant.mamage_profile}",
              options: Options(followRedirects: false, headers: {
                "Authorization":
                    "Bearer ${PreferenceUtils.getString("accesstoken")}"
              }));
          print("-----this is url $response");
          if (response.statusCode == 200) {
            print("+++++this is manageprofile ${response.data}");
            setState(() {
              athleteuserdetails = response.data["userdetails"];
              print("---this is profile data== $athleteuserdetails");
              print(
                  "profile picture path--- ${athleteuserdetails["picturePathS3"]}");
            });
          } else if (response.statusCode == 401) {
            return Get.offAll(Loginscreennew());
          } else {
            //setState(() => _isFirstLoadRunning = false);
          }
        } catch (e) {
          print(e);
          //setState(() => _isFirstLoadRunning = false);
        }
      } else {
        MyApplication.getInstance()!
            .showInSnackBar(AppString.no_connection, context);
      }
    });
  }

  /////TODO publicprofile Loanch Api /////////
  profile_lounch(String profilelink) async {
    log('this is call profile_lounch api call', name: "Profile Link");
    try {
      Dio dio = Dio();
      var params = {
        "url":"http://packhubweb.s3-website-us-west-2.amazonaws.com/$profilelink"
      };
      print("response url  ====> ${params}");
      print("response url  ====> ${PreferenceUtils.getString("accesstoken")}");

      var response = await dio.post(AppConstant.public_profile,
          data: params,
          options: Options(followRedirects: false, headers: {
            "Authorization":
            "Bearer ${PreferenceUtils.getString("accesstoken")}"
          }));
      if (response.statusCode == 200) {
        print("+++++this is admin clg recruiter${response.data}");
        persnoledetails = response.data["userDetails"];
        print("+++++this is admin${persnoledetails["profileName"]}");
        // if (await canLaunchUrl(Uri.parse())){
        //   await launchUrl(Uri.parse("http://packhubweb.s3-website-us-west-2.amazonaws.com/zelizelensky"));
        // } else {
        //   // can't launch url
        // }
      }
    } catch (e) {
      print(e);
      setState(() => _isFirstLoadRunning = false);
    }
  }
}
