// To parse this JSON data, do
//
//     final recruiterData = recruiterDataFromJson(jsonString);

import 'dart:convert';

RecruiterData recruiterDataFromJson(String str) => RecruiterData.fromJson(json.decode(str));

String recruiterDataToJson(RecruiterData data) => json.encode(data.toJson());

class RecruiterData {
  RecruiterData({
    this.statusCode,
    this.message,
    this.result,
  });

  int? statusCode;
  String? message;
  List<Result>? result;

  factory RecruiterData.fromJson(Map<String, dynamic> json) => RecruiterData(
    statusCode: json["statusCode"],
    message: json["Message"],
    result: List<Result>.from(json["result"].map((x) => Result.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "Message": message,
    "result": List<dynamic>.from(result!.map((x) => x.toJson())),
  };
}

class Result {
  Result({
    this.userId,
    this.userName,
    this.contact,
    this.bio,
    this.image,
    this.organizationName,
    this.organizationCity,
    this.organizationState,
    this.userEmail,
    this.joinDate,
    this.divisionName,
    this.city,
    this.state,
    this.subscription,
    this.role,
    this.sport,
    this.isBookMarked,
  });

  int? userId;
  int? roleID;
  int? divID;
  String? userName;
  String? contact;
  String? bio;
  String? image;
  String? organizationName;
  String? organizationCity;
  String? organizationState;
  String? userEmail;
  DateTime? joinDate;
  String? divisionName;
  String? city;
  String? state;
  String? subscription;
  String? role;
  String? sport;
  bool? isBookMarked;


  factory Result.fromJson(Map<String, dynamic> json) => Result(
    userId: json["userID"],
    userName: json["userName"],
    contact: json["contact"],
    bio: json["bio"],
    image: json["image"],
    organizationName: json["organizationName"],
    organizationCity: json["organizationCity"],
    organizationState: json["organizationState"],
    userEmail: json["userEmail"],
    joinDate: DateTime.parse(json["joinDate"]),
    divisionName: json["divisionName"],
    city: json["city"],
    state: json["state"],
    subscription: json["subscription"],
    role: json["role"],
    sport: json["sport"],
    isBookMarked: json["isBookMarked"],
  );

  Map<String, dynamic> toJson() => {
    "userID": userId,
    "userName": userName,
    "contact": contact,
    "bio": bio,
    "image": image,
    "organizationName": organizationName,
    "organizationCity": organizationCity,
    "organizationState": organizationState,
    "userEmail": userEmail,
    "joinDate": joinDate,
    "divisionName": divisionName,
    "city": city,
    "state": state,
    "subscription": subscription,
    "role": role,
    "sport": sport,
    "isBookMarked": isBookMarked,
  };
}
