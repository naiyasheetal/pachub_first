const String hamburger = "assets/icons/hamburger.svg";
const String notifiction = "assets/icons/notifiction.svg";
const String close = "assets/icons/close.svg";
const String drawerImage = "assets/images/drawerlogo.svg";
const String userImage = "assets/images/userimage.png";
const String avatarImage = "assets/images/avatar.png";
const String logoutImage = "assets/icons/logout_icon.svg";
const String home_icon = "assets/icons/home.svg";
const String advisor_icon = "assets/icons/advisors.svg";
const String profile_icon = "assets/icons/profile_icon.svg";
const String userProfile_image = "assets/images/user_profile.svg";
const String bookmark_icon = "assets/icons/bookmark.svg";
const String message_icon = "assets/icons/chat_icon.svg";
const String settings_icon = "assets/icons/settings.svg";
const String loginFrame = "assets/images/loginframe.svg";
const String logo = "assets/images/Logo.png";
const String splashbackimage = "assets/images/splash.png";
const String collegerecruitersave = "assets/icons/Subtract.png";
const String location_icon = "assets/icons/location.svg";
const String call_icon = "assets/icons/call_icon.svg";
const String world_icon = "assets/icons/world_icon.svg";
const String hidePassword = "assets/icons/eyehide.png";
const String showPassword = "assets/images/eyeshow.png";
const String unselecthome = "assets/icons/unselecthome.svg";
const String group_icon = "assets/icons/group.svg";
const String selectgroup = "assets/icons/selectgroup.svg";
const String selectedmessage = "assets/icons/selectedmessage.svg";
const String selectedadvisors = "assets/icons/selectedadvisors.svg";
const String serach_suffix_icon = "assets/icons/serach_suffix_icon.svg";
const String serach_icon = "assets/icons/search_icon.svg";
const String universitylogo = "assets/images/universitylogo.png";
const String collageuserImage = "assets/images/collageuser.png";
const String universitylogo2 = "assets/images/universitylogo2.png";
const String dashboardVector = "assets/images/vector.png";
const String contactIcon = "assets/icons/contacts.svg";
const String dotIcon = "assets/icons/doticon.svg";
const String baseballIcon = "assets/icons/baseball.svg";
const String teamIcon = "assets/icons/team.svg";
const String forewordIcon = "assets/icons/foreword.svg";
const String cakeIcon = "assets/icons/cake.svg";
const String emailIcon = "assets/icons/email.svg";
const String chartIcon = "assets/icons/charticon.svg";
const String locationIcon = "assets/icons/location.svg";
const String video = "assets/video/newvideo.mp4";
const String playIcon = "assets/icons/play.svg";
const String magicTreeVideo = "assets/video/magictree.mp4";
const String sunsetVideo = "assets/video/sunset.mp4";
const String horseImage = "assets/images/horse.png";
const String magicTreeImage = "assets/images/magicTree.png";
const String sunsetImage = "assets/images/sunset.png";
const String groupVideo = "assets/images/groupVideo.svg";
const String bookmarktrue = "assets/icons/bookmark.png";
const String baseball = "assets/images/baseball.svg";
const String basketball = "assets/images/basketball.svg";
const String football = "assets/images/football.svg";
const String volleyball = "assets/images/volleyball.svg";
const String cricket = "assets/images/cricket.svg";
const String smileIcon = "assets/icons/smile.svg";
const String sendIcon = "assets/icons/send.svg";
const String platinumbackground = "assets/images/platinumbackground.png";
const String userImages1 = "assets/images/userimage1.png";
const String userImages2 = "assets/images/userimage2.png";
const String userImages3 = "assets/images/userimage3.png";
const String userImages4 = "assets/images/userimage4.png";
const String userImages5 = "assets/images/userimage5.png";
const String userImages6 = "assets/images/userimage6.png";
const String deleteBackground = "assets/icons/deletebackground.svg";
const String checkCircle = "assets/icons/checkcircle.svg";
const String deleteIcon = "assets/icons/delete.svg";
const String approveIcon = "assets/icons/approve.svg";
const String userPlusIcon = "assets/icons/adduserplus.svg";
const String addUserIcon = "assets/icons/adduser.svg";
const String revenueIcon = "assets/icons/revenue.svg";
const String messageCircleIcon = "assets/icons/messagecircle.svg";
const String barchartIcon = "assets/icons/barchart.svg";
const String briefcaseIcon = "assets/icons/briefcase.svg";
const String linkIcon = "assets/icons/link.svg";
const String baseball_icon = "assets/icons/baseball_Icon.svg";
const String contact_icon = "assets/icons/Contacts_icon.svg";








