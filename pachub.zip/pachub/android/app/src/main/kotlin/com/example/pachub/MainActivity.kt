package com.example.pachub

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
